﻿namespace Assignment_Day_2
{
    internal class Program
    {
        static void Main()
        {
            //class1 o1 = new class1(1, "Amol", 123465, 10);
            //class1 o2 = new class1(1, "Amol", 123465);
            //class1 o3 = new class1(1, "Amol");
            //class1 o4 = new class1(1);
            class1 o = new class1();
            o.Name = "harshal";
            Console.WriteLine(o.Name);
            o.EmpNo = 1;
            Console.WriteLine(o.EmpNo);
            o.Basic = 30000;
            Console.WriteLine(o.Basic);
            o.DeptNo = 101;
            Console.WriteLine(o.DeptNo);
            o.GetNetSalary();


        }
    }

    public class class1
    {
        private string name;
        private int empNo;
        private decimal basic;
        private short deptNo;

        public string Name
        {
            set
            {
                if (value == "harshal")
                    name = value;
                else
                    Console.WriteLine("invalid Name");
            }
            get
            {
                return name;
            }
        }

        public int EmpNo
        {
            set
            {
                if (value > 0)
                    empNo = value;
                else
                    Console.WriteLine("invalid empno");
            }
            get
            {
                return empNo;
            }
        }

        public decimal Basic
        {
            set
            {
                if (value > 20000 && value < 40000)
                    basic = value;
                else
                    Console.WriteLine("invalid empno");
            }
            get
            {
                return basic;
            }
        }

        public short DeptNo
        {
            set
            {
                if (value > 0)
                    deptNo = value;
                else
                    Console.WriteLine("invalid empno");
            }
            get
            {
                return deptNo;
            }
        }
        public void GetNetSalary()
        {
            basic = basic * (decimal)12 * (decimal)0.5;
            Console.WriteLine(basic);
        }
    }
}