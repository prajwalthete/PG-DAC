﻿namespace StaticMembers
{
    internal class Program
    {
        static void Main()
        {
            Class1 o1 = new Class1();
            Class1 o2 = new Class1();
            o1.i = 100;
            o2.i = 200;
            o1.Display();

            Class1.s_i = 1234;
            Class1.s_Display();


        }
    }
    public class Class1
    {
        public int i;
        public static int s_i;  //single copy (shared data)


        public void Display()
        {
            Console.WriteLine("display");
            Console.WriteLine(i);
            Console.WriteLine(s_i);

        }

        //can be called without creating an object
        public static void s_Display()
        {
            Console.WriteLine("static display");
            //Console.WriteLine(i);
            Console.WriteLine(s_i);

        }
    }
}